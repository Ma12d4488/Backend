﻿using Microsoft.AspNetCore.Identity;

namespace E_Commerce_API.Models
{
    public class Role : IdentityRole
    {

    }
}
