﻿namespace E_Commerce_API.DTOs
{
    public class CreateRoleDto
    {
        public string RoleName { get; set; }
    }
}
